﻿using System;
using System.IO;

namespace ReadFile
{
    class Program
    {

        // main method
        static void Main(string[] args)
        {
            // call a methd to read the file and return the data in a int array
            int[] data = ReadFile();

            // method to calculate the amount of grounds needed for the day and return the data
            int grounds = CalculateGrounds(data);

            // method to calculate the amount of water needed for the day and return the data
            int water = CalculateWater(data);

            // write the data to the console
            Console.WriteLine("\nThe coffee machine will need the following for the day's orders");
            Console.WriteLine("oz of grounds: " + grounds);
            Console.WriteLine("Cups of Water: " + water);
        }


        // method to calculate the amount of grounds needed for the day
        private static int CalculateGrounds(int[] data)
        {
            int oz = 0;

            // loop through the array and calculate the amount of grounds needed
            for (int i = 0; i < data.Length; i++)
            {
                oz += data[i] * 2;
            }

            return oz;
        }

        // method to calculate the amount of water needed for the day
        private static int CalculateWater(int[] data)
        {
            int water = 0;

            // oop through the array and calculate the amount of water needed
            for (int i = 0; i < data.Length; i++)
            {
                water += data[i];
            }

            return water;

        }


        // function to read the file and return the data in a int array
        private static int[] ReadFile()
        {
            // create a string array to hold the data from the file
            string[] lines = File.ReadAllLines("input.txt");

            // create an int array to hold the data from the file
            int[] data = new int[lines.Length];

            // loop through the string array and convert the data to int
            for (int i = 0; i < lines.Length; i++)
            {
                data[i] = int.Parse(lines[i]);
            }
            // return the int array
            return data;
        }
    }
}