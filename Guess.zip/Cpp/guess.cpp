#include <iostream>
#include <vector>
#include <ctime>
using namespace std;

const int NUMBER_OF_SHIPS = 10;
const int ROWS = 16;
const int COLS = 16;

vector<pair<int, int>> getCoordinates()
{
    vector<pair<int, int>> coordinateList;

    for (int i = 0; i < ROWS; ++i)
        for (int j = 0; j < COLS; ++j)
            coordinateList.push_back(make_pair(i, j));

    return coordinateList;
}

bool isUniqueCoordiante(vector<int> list, int key)
{
    for (int i : list)
        if (i == key)
            return false;
    return true;
}

void setRandomCoordinates(vector<int> &randomCoordinates)
{
    srand(time(nullptr));
    // Number of Cooridinates in Grid
    const int POSITIONS = 256;
    int num{};
    for (int i = 0; i < NUMBER_OF_SHIPS; i++)
    {
        do
        {
            num = rand() % POSITIONS;
        } while (!isUniqueCoordiante(randomCoordinates, num));
        randomCoordinates.push_back(num);
    }
}

void setGrid(vector<vector<bool>> &grid)
{
    // List of Coordinates in the grid
    vector<pair<int, int>> coordinateList = getCoordinates();
    // List that contain the index to get random Coordinates from Coordinate List
    vector<int> randomCoordinates;
    setRandomCoordinates(randomCoordinates);

    for (int i = 0; i < NUMBER_OF_SHIPS; ++i)
    {
        pair<int, int> coordiante = coordinateList[randomCoordinates[i]];
        // Random Position of Ship in Grid is set
        grid[coordiante.first][coordiante.second] = true;
    }
}

string getResult(const vector<vector<bool>> &grid, int x, int y)
{
    if (grid[x][y] == true)
        return "HIT";
    if (y + 1 < COLS && grid[x][y + 1] == true)
        return "NEAR MISS";
    if (y - 1 < COLS && y >= 0 && grid[x][y - 1] == true)
        return "NEAR MISS";
    if (x + 1 < ROWS && grid[x + 1][y] == true)
        return "NEAR MISS";
    if (x - 1 < ROWS && x >= 0 && grid[x - 1][y] == true)
        return "NEAR MISS";
    if (y + 1 < COLS && x + 1 < ROWS && grid[x + 1][y + 1] == true)
        return "NEAR MISS";
    if (y - 1 >= 0 && x - 1 >= 0 && grid[x - 1][y - 1] == true)
        return "NEAR MISS";
    if (y + 1 < COLS && x - 1 >= 0 && grid[x - 1][y + 1] == true)
        return "NEAR MISS";
    if (y - 1 >= 0 && x + 1 < ROWS && grid[x + 1][y - 1] == true)
        return "NEAR MISS";
    return "MISS";
}

int main()
{
    vector<vector<bool>> grid(16, vector<bool>(16));
    setGrid(grid);
    int x_coordinate{}, y_coordinate{};
    do
    {
        cout << "\n**********Coordinates*************\n";
        cout << "x_coordinate: ";
        cin >> x_coordinate;
        cout << "y_coordinate: ";
        cin >> y_coordinate;
        if (x_coordinate >= 16 || y_coordinate >= 16)
            cout << "\nInvalid Position!\n\n";
    } while (x_coordinate >= 16 || y_coordinate >= 16);
    cout << getResult(grid, x_coordinate, y_coordinate);
}